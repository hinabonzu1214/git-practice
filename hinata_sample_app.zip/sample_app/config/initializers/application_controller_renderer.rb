# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'bd13bdeddac215c389c306f8806f23042c8db39a74d7120e912c0b3a32c516545c4ff3f5df972675c6075c1dd4c0d4d4988c88f6b526fcc22586db8e3562123e'
