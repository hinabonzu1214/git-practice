class ApplicationController < ActionController::Base
    def top
    end
end
