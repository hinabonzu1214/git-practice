class TodolistController < ApplicationController
  def new
    @lsit = List.new
  end
  
  def create
    # make instance
    list = List.new(list_params)
    # save method
    list.save
    # redilect top
    redirect_to '/top'
  end

  private
  # string paramator
  def list_params
    params.require(:list).permit(:title, :body)
  end
end
